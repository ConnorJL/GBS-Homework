#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <unistd.h>
#include<sys/wait.h>

int main(int argc, char *argv[]) {
    int c;
    int r = 0;
    int k = 10;
    int n = 1;
    while ((c = getopt (argc, argv, "k:n:r")) != -1)
        switch (c)
        {
            case 'k':
                k = atoi(optarg);
                break;
            case 'n':
                n = atoi(optarg);
                break;
            case 'r':
                r = 1;
                break;
            default:
                printf("%c", (char)c);
                perror("Unknown argument type");
                exit(1);
        }
    time_t t = time(NULL);
    struct tm *tm = localtime(&t);
    char s[64];
    strftime(s, sizeof(s), "%c", tm);
    printf("Start: %s\n", s);
    int processes[2];
    int newPr = 0;

    srand(getpid());
    float sto = k;
    if (r) {
        sto *= 0.5 + ((float)(rand()))/((float)(RAND_MAX));
    }
    for (int i = 0; i < n; i++) {
        if ((newPr = fork()) == 0) {
            int p = 1;

//            printf("sto %d %d\n", rand(), r);
            for (; p <= sto; p++) {
                printf("%d %d %d\n", getpid(), getppid(), p);
                if (p != sto) {
                    sleep(1);
                }
            }
            printf("Exit-Code: %d\n", (getpid() + p - 1) % 100);
            exit(0);
        } else {
            processes[i] = newPr;
        }
    }
    if (newPr != 0) {
//        pid_t child_pid, wpid;
//        int status = 0;
//        while ((wpid = wait(&status)) > 0);
        int returnStatus;
        for (int i = 0; i < n; i++){
            waitpid(processes[i], &returnStatus, 0);
        }
//            waitpid();
        t = time(NULL);
        tm = localtime(&t);
        strftime(s, sizeof(s), "%c", tm);
        printf("Ende: %s\n", s);
    }

    exit(0);
}
