#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <unistd.h>
#include<sys/wait.h>

int main(int argc, char *argv[]) {
    time_t t = time(NULL);
    struct tm *tm = localtime(&t);
    char s[64];
    strftime(s, sizeof(s), "%c", tm);
    printf("Start: %s\n", s);
    if (fork() == 0) {
        int k = 1;
        int sto = atoi(argv[1]);
        for (; k <= sto; k++) {
            printf("%d %d %d\n", getpid(), getppid(), k);
            if (k != sto) {
                sleep(1);
            }
        }
        printf("Exit-Code: %d\n", (getpid() + k - 1) % 100);
        exit(0);
    } else {
        wait(NULL);
        t = time(NULL);
        tm = localtime(&t);
        strftime(s, sizeof(s), "%c", tm);
        printf("Ende: %s\n", s);
    }

    return 0;
}