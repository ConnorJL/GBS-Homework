#include <stdio.h>
#include <stdlib.h>
#include "list.h"

list_t *list_init () {
    list_t *lst = (list_t *)malloc(2 * (sizeof(void *)));
    lst->first = NULL;
    lst->last = NULL;
    return lst;
}

struct list_elem *list_insert (list_t *list, int *data) {
    struct list_elem *elm = (struct list_elem *)malloc(2 * (sizeof(void *)));
    elm->next = list->first;
    elm->data = data;
    list->first = elm;
    if (list->last == NULL) {
        list->last = elm;
    }
    return elm;
}

struct list_elem *list_append (list_t *list, int *data) {
    struct list_elem *elm = (struct list_elem *)malloc(2 * (sizeof(void *)));
    elm->next = NULL;
    elm->data = data;
    if (list->last == NULL) {
        list->first = elm;
        list->last = elm;
    }
    else {
        list->last->next = elm;
        list->last = elm;
    }
    return elm;
}

int list_remove (list_t *list, struct list_elem *elem) {
    if (list->first == elem) {
        list->first = elem->next;
    }
    else {
        struct list_elem *curr = list->first;
        if (list->first == elem) {
            list->first = list->first->next;
        }
        if (curr != NULL) {
            while (1) {
                if (curr->next == elem) {
                    curr->next = curr->next->next;
                    if (curr->next == NULL) {
                        list->last = curr;
                    }
                    break;
                }
                if (curr->next == NULL) {
                    return -1;
                }
                curr = curr->next;
            }
        }
    }
    return 0;
    free(elem);
}

void list_finit (list_t *list) {
    struct list_elem *curr = list->first;
    if (curr != NULL) {
        while (1) {
            if (curr->next == NULL) {
                list->last = NULL;
                list->first = NULL;
                break;
            }
            curr = curr->next;
            list_remove(list, list->first);
        }
    }
}

int list_first(list_t *list) {
    int *r = list->first->data;
    list_remove(list, list->first);
    return *r;
}

void list_print (list_t *list, void (*print_elem) (int *)) {
    struct list_elem *curr = list->first;
    while (1) {
        print_elem(curr->data);
        if (curr->next == NULL) {
            break;
        }
        curr = curr->next;
    }
}

void list_dump (list_t *list, void (*print_elem) (struct list_elem *)) {
    struct list_elem *curr = list->first;
    while (1) {
        print_elem(curr);
        if (curr->next == NULL) {
            break;
        }
        curr = curr->next;
    }
}

struct list_elem *list_find (list_t *list, int *data, int (*cmp_elem) (const int *, const int *)) {
    struct list_elem *curr = list->first;
    if (curr != NULL) {
        while (1) {
            if (cmp_elem(curr->data, data) == 0) {
                return curr;
            }
            if (curr->next == NULL) {
                return NULL;
            }
            curr = curr->next;
        }
    }
    return NULL;
}

//ssh -p 22222 student@localhost